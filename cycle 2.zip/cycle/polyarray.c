#include<stdio.h>
int main()
{ 
  int a[50],b[50],c[50],i,j,k,d1,d2,d3;
  printf("enter the largest degree:");
  scanf("%d",&d1);
  for(i=0;i<=d1;i++)
  {
    printf("enter coeff of x^%d:",i);
    scanf("%d",&a[i]);
  }
  printf("enter the largest degree of poly2:");
  scanf("%d",&d2);
  for(j=0;j<=d2;j++)
  {
    printf("enter coeff of x^%d:",j);
    scanf("%d",&b[j]); 
  }
  printf("Expression 1 :");
  printf("%d",a[0]);
  for(i=1;i<=d1;i++)
  {
    printf("+%dx^%d",a[i],i);
  }
  printf("\n");
  printf("Expression 2 :");
  printf("%d",b[0]);
  for(j=1;j<=d2;j++)
  {
    printf("+%dx^%d",b[j],j);
  }
   printf("\n");     
  d3=d1>d2?d1:d2;
  for(i=0,j=0;i<=d3,j<=d3;i++,j++)
  {
    c[k]=a[i]+b[j];
    k++;
  }
  printf("after adding:\n%d",c[0]);
  for(k=1;k<=d3;k++)
  {
    printf("+%dx^%d",c[k],k);
  }
  return 0;
}